# A Simple Calculator Flet App

An example of a minimal Flet app.

To run the app:

```shell
flet run
```

